declare module "webpack-sources";
